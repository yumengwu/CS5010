package freecell.model;

/**
 * This enum represent suit colors. Cards have two color: red and black.
 */
public enum SuitColor {
  red, black
}
