Setup:
Unzip the zipfile and change directory to res.
Input "java -jar assignment9.jar" in terminal to run jar file.
Then input 1 to run command-line view, or input 2 to run GUI view.

Requirement:
Java 1.8 jdk and jre must be installed correctly.