Setup:
Unzip the zipfile and change directory to res.
Input "java -jar assignment8.jar" in terminal to run jar file.

Requirement:
Java 1.8 jdk and jre must be installed correctly.