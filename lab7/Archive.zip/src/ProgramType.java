/**
 * This enum represent program type, including MSCS and ALIGN.
 */
public enum ProgramType {
  MSCS, ALIGN
}
